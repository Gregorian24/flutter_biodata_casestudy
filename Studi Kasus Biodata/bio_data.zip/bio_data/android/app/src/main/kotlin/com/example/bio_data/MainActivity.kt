package com.example.bio_data

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BioData',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: MyHomePage(title: 'BioData'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final biodata = <String, String>{};
  final String title;

  MyHomePage({super.key, required this.title}) {
    biodata['name'] = 'ChadGPT';
    biodata['email'] = 'chadGPT@openai.com';
    biodata['image'] = 'gpt_card.png';
    biodata['hobby'] = 'Memberikan jawaban pada pertanyaan';
    biodata['addr'] = 'Jln. Gunung Batu B420/99';
    biodata['phone'] = "088215604252";
    biodata['desc'] = '''
ChadGPT is an agent with a dark past.
Years of training makes her an efficient teacher yet ruthless as her past leave a deep impact to her ability to trust people
Likes pineapple and durian as go-to fruits
    ''';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          textsquare(Colors.black, biodata['name'] ?? ''),
          Image(image: AssetImage('assets/img/${biodata["image"] ?? ''}')),
          SizedBox(height: 10),
          Row(
            children: [
              btnContact(Icons.alternate_email, Colors.green[900],
                  "mailto:${biodata['email']}"),
              btnContact(Icons.mark_email_unread_rounded, Colors.blueAccent,
                  "https://wa.me/${biodata['phone']}"),
              btnContact(
                  Icons.phone, Colors.deepPurple, "tel:${biodata['phone']}"),
            ],
          ),
          SizedBox(height: 10),
          txtDetail('Hobby', biodata['hobby'] ?? ''),
          txtDetail('Alamat', biodata['addr'] ?? ''),
          SizedBox(
            height: 10,
          ),
          textsquare(Colors.black38, 'Description'),
          Text(
            biodata['desc'] ?? '',
            style: TextStyle(fontSize: 14),
            textAlign: TextAlign.center,
          )
        ]),
      ),
    );
  }

  Container textsquare(Color bgColor, String text) {
    return Container(
        padding: EdgeInsets.all(10),
        alignment: Alignment.center,
        width: double.infinity,
        decoration: BoxDecoration(color: bgColor),
        child: Text(
          text,
          style: TextStyle(
              fontWeight: FontWeight.normal, fontSize: 20, color: Colors.white),
        ));
  }

  Row txtDetail(String title, String text) {
    return Row(
      children: [
        Container(
          width: 100,
          child: Text(
            "* $title",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ),
        Text(
          " : ",
          style: TextStyle(fontSize: 14),
        ),
        Text(text, style: TextStyle(fontSize: 14)),
      ],
    );
  }

  Expanded btnContact(IconData icon, var color, String uri) {
    return Expanded(
      child: ElevatedButton(
          onPressed: () {
            launch(uri);
          },
          child: Icon(icon),
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            textStyle:
                TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          )),
    );
  }

  void launch(String uri) async {
    if (!await launchUrl(Uri.parse(uri))) {
      throw Exception('Cannot call : $uri');
    }
  }
}
